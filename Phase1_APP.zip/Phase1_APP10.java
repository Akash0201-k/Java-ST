Writing code for a try block with parameters.


public Line (Vector start, Vector end) throws Exception  {

    if (start.equals (end)) {
        throw new Exception ( "Points are the same" );
    }

    else {

        this.start = start;
        this.end = end;

        modelLine (start, end);            
    }        
}



public BoundedLine (Vector start, Vector end) throws Exception {

    try {
        super (start, end);
    }
    catch (Exception e) {
        throw e;
    }

    applyBoundaries (start, end);        
}