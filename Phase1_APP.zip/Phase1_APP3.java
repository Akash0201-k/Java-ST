Write a program to demonstrate the while loop.


package loops;

import java.util.Scanner;

public class WhileLoop {
	public static void main(String[] args) {
		
	int PINbyDB= 1234;
	
	Scanner scanner= new Scanner(System.in);
	System.out.println("Enter your PIN");
	int PINbyUser= scanner.nextInt();
	while(PINbyUser!= PINbyDB) {
		System.out.println("PIN Invalid , try again");
		PINbyUser= scanner.nextInt();
	}
	System.out.println("welcome");
}
}