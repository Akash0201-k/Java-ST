Write a program in Java to perform implicit and explicit type casting.


package demo;

public class TypeCasting {
		public static void main(String[] args) {
			//implicit type casting
			int num1=10;
			double num2=num1;
			System.out.println(num2);
			
			//explicit type casting
			double num3=15.5;
			int num4= (int)num3;
			System.out.println(num4);
		}
}
