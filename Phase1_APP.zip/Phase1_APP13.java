Writing a program in Java to verify implementations of collections.



package collectionframeworks;

import java.util.ArrayList;

public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList<String> cities= new ArrayList<>();
		cities.add("Chennai");
		cities.add("Mumbai");
		for(String t : cities) {
			System.out.println(t);
		}
		System.out.println(cities.get(1));		
		System.out.println(cities.size());
	
	}
}



package collectionframeworks;
import java.util.HashMap;
import java.util.Map;
public class HashMapDemo {
	public static void main(String[] args) {
		HashMap<String, Integer> td=new HashMap<>();
		td.put("Ram", 123456);
		td.put("Janu",683464);
		td.put("Akash", 546546);
		for(Map.Entry m: td.entrySet())
		{
			System.out.println(m.getKey()+ " - "  + m.getValue());
		}
	}
}



package collectionframeworks;

import java.util.HashSet;

public class HashsetDemo {
	public static void main(String[] args) {
		HashSet<String> cities= new HashSet<>();
		cities.add("Chennai");
		cities.add("Mumbai");
		for(String t : cities) {
			System.out.println(t);
		}
		System.out.println(cities.contains("Mumbai"));
		System.out.println(cities.size());

}
}


package collectionframeworks;

import java.util.LinkedList;

public class LinkedListDemo {
	public static void main(String[] args) {
		LinkedList<String> cities= new LinkedList<>();
		cities.add("Chennai");
		cities.add("Mumbai");
		for(String t : cities) {
			System.out.println(t);
		}
		System.out.println(cities.get(0));		
		System.out.println(cities.contains("Paris"));

		System.out.println(cities.size());

	}
}
